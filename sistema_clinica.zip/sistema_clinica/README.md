Integrantes do Grupo:
Anna Claudia Barros Silveira - RA:822144028
Diego Jaldin - RA:821119998
Gabriel Lima Ruas - RA:821235160
Geovanna Holanda da Silva- RA:819115164
Luidy Yutá Pereira Monteiro - RA:82119379
Pedro Henrique Gomes Candido de Lima - RA:821148496
Rafael Freitas Venosa - RA:82117385

Entrega 26/09:
Implementação do Primeiro Microsserviço
- Foi implementado o cadastro (utilizados o Thunder Client)
- Tivemos dificuldade em implementar o login, porém será entregue na próxima data.
